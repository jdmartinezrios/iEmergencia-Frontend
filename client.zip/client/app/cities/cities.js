'use strict';

angular.module('startUpApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('cities-list', {
        url: '/cities-list',
        template: '<cities-list></cities-list>'
      });
  });
