'use strict';

angular.module('startUpApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('typeDocuments-list', {
        url: '/typeDocuments-list',
        template: '<type-documents-list></type-documents-list>'
      });
  });
