'use strict';

angular.module('startUpApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('countries-list', {
        url: '/countries-list',
        template: '<countries-list></countries-list>'
      });
  });
