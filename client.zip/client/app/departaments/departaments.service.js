'use strict';

function departamentsService($resource,API) {
  return $resource(API + '/api/departamentos/:id',
  {id:'@id'},
  {update:
    {method:'PUT'}
  });
}

angular.module('startUpApp')
  .service('departamentsService',departamentsService);
