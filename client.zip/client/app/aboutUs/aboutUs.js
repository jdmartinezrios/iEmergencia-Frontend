'use strict';

angular.module('startUpApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('aboutUs', {
        url: '/aboutUs',
        template: '<about-us></about-us>'
      });
  });
